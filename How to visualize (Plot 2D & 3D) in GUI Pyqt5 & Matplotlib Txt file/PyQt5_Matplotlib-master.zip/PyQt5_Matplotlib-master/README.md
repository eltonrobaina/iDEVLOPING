# PyQt5_Matplotlib
Making Desktop App with PyQt5 and matplotlib
